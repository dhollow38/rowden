#Set dependencies
import json
import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    
    #Determine if a search keyword is provided in the invoking command. If not use the default
    if 'keyword' in str(event):
        
        keyword = event['keyword']
        
    else:
        
        keyword = 'Rowden'
    
    #Determine if a target region(s) has been provided in the invoke command. If not default to all regions    
    if 'regions' in str(event):
        
        regions = event['regions']
        
    else: 
        
        #Create a list of all available regions in AWS
        regions = (boto3.client('ec2')).describe_regions()['Regions']
    
    print('Number of regions to be scanned: {}'.format(len(regions)))
    
    #Define a dict object to hold the results for the shutdown operation
    results = {}
    
    #Loop through each region in turn and create an EC2 boto3 Resource and Client for that Region
    for region in regions:
        
        regName = region['RegionName']
        
        #Define a dict object to hold the region specific results
        regionResults = {}
        
        #Define a list to hold all the Instances that should be stopped and one for Instances to be hibernated
        toStop = []
        toHibernate = []
        
        #Define a dict object to hold the stop and hiberante shutdown action results
        stopRes = {}
        hibernateRes = {}
        
        print('Checking for instances in {}'.format(regName))
        
        #Create a boto3 EC2 resource for the region being scanned
        ec2res = boto3.resource('ec2', regName)
        
        #Create a list of all EC2 instances in the region. All states are included in this list
        instances = ec2res.instances.all()
        
        #Loop through the list of instances
        for instance in instances:
            
            #Check if the instance is in a pending (0) or running (16) state. If not move onto the next
            if instance.state['Code'] > 16:
                
                print('Instance {} state is {}. Moving on....'.format(instance.id, instance.state['Name']))
                
                continue
            
            #Create a boto3 EC2 client for easier interaction with instances in the scanned region
            ec2 = boto3.client('ec2', regName)
            
            #Check for the keyword in the Tags of the instance. The Tags include the 'Name' of the instance. If found start shut down sequence
            if keyword in str(instance.tags):
                
                print('Found keyword: {} in Tags for {}: {}'.format(keyword, instance.id, instance.tags))
                
                #Get more information about the instance
                instanceDets = ec2.describe_instances(InstanceIds=[instance.id])['Reservations'][0]['Instances'][0]
                
                #Check if the instance is comnfigured to hibernate rather than shut down. If so add it to the hibernate instance list
                if instanceDets['HibernationOptions']['Configured']:
                    
                    toHibernate.append(instance.id)
                    
                else:
                    
                    toStop.append(instance.id)
        
        #Check if the toStop instance list is empty. If not then call the shut down method with hibernate set to False passing the EC2 client with it
        if toStop != []:
            
            stopRes = shutdown(ec2, toStop, False)
            
        else:
            
            print('No instances to be stopped.....')
        
        #Check if the toHibernate instance list is empty. If not then call the shut down method with hibernate set to True passing the EC2 client with it 
        if toHibernate != []:
            
            hibernateRes = shutdown(ec2, toHibernate, True)
            
        else:
            
            print('No instances to be hibernated.....')
        
        #Set the regionResults to be the returned values from the shut down method calls    
        regionResults = {'Stopped': stopRes, 'Hibernated': hibernateRes}
        
        #Adds the regionResults to the results dict
        results[regName] = regionResults
        
    print('Final Results: {}'.format(json.dumps(results)))
    
    return results

#The shutdown method. Takes an EC2 client, instance list and a boolean for hibernated as inputs                    
def shutdown(ec2, instances, hibernate):
    
    print('Commencing shutdown.....')
    
    #Defines lists to hold instance details for completed and failed instance shut downs
    completed = []
    failed = []
    
    #Loop through the list of instances provided
    for instance in instances:
        
        #A try and except error handling block. Allows for a single instance shut down failure to be handled and for the process to continue
        try:
    
            #The command to shut down the instance. Hibernate option determined by the call inputs
            shutdown = ec2.stop_instances(InstanceIds=[instance],
                                          Hibernate=hibernate)
            
            #Add the instance id to the completed list if it completes
            completed.append(instance)
        
        #Catch any error thrown during the shut down process                              
        except ClientError as ce:
        
            print('Error shutting down instance: {}. Error message'.format(ce))
            
            shutdown = ce
            
            #Add the instance id to the failed list if it failed to shut down
            failed.append(instance)
                                  
        print('Shutdown: {}'.format(shutdown))
    
    #Define a dict object to hold the details for all completions and failures for this method call   
    response = {'Completed':completed, 'Failed':failed}
    
    #Return the response dict object to the calling method                              
    return response
                
                
